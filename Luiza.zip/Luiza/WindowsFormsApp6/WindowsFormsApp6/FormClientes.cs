﻿using System;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class FormClientes : Form
    {
        private readonly string caminhoArquivo = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "cliente.json"
            );
        public FormClientes()
        {
            InitializeComponent();
        }

        // Executado quando o formulário é aberto
        private void Form1_Load(object sender, EventArgs e)
        {
            // Verifica se o arquivo já existe
            if (!File.Exists(caminhoArquivo))
            {
                return;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clientes cliente = new Clientes
            {
                Nome = Txt_Nome.Text,
                Telefone = Txt_Telefone.Text,
                Cpf = Txt_Cpf.Text,
                Email = Txt_Email.Text,
                Cep = Txt_Cep.Text,
                Estado = Txt_Estado.Text,
                Cidade = Txt_Cidade.Text,
            };

            JsonSerializerOptions opcoes = new JsonSerializerOptions
            {
                WriteIndented = true
            };

            string json = JsonSerializer.Serialize(cliente, opcoes);

            File.WriteAllText(caminhoArquivo, json);

            MessageBox.Show(
                $"Cliente salvo com sucesso!\n\nArquivo:\n{caminhoArquivo}",
                "Salvar cliente",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
                );
        }



        private void button2_Click(object sender, EventArgs e)
        {
        
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
